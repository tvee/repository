import urllib, urllib2, re, cookielib, os, sys, socket
import xbmc, xbmcplugin, xbmcgui, xbmcaddon

import utils, sqlite3
import YDStreamExtractor 


def BVLSMain():
    BVLSaddDir('Maandag','http://sebn.sc/',115,'http://sebn.sc/images/logo.png')
    BVLSaddDir('Dinsdag','http://sebn.sc/',115,'http://sebn.sc/images/logo.png')
    BVLSaddDir('Woensdag','http://sebn.sc/',115,'http://sebn.sc/images/logo.png')
    BVLSaddDir('Donderdag','http://sebn.sc/',115,'http://sebn.sc/images/logo.png')
    BVLSaddDir('Vrijdag','http://sebn.sc/',115,'http://sebn.sc/images/logo.png')
    BVLSaddDir('Zaterdag','http://sebn.sc/',115,'http://sebn.sc/images/logo.png')
    BVLSaddDir('Zondag','http://sebn.sc/',115,'http://sebn.sc/images/logo.png')
    listhtml = getHtml('http://welkedagishet.nl/','')
    match = re.compile('<div id="day">.*?h1>(.*?)</h1>.*?h1>(.*?)</h1>', re.IGNORECASE | re.DOTALL).findall(listhtml)
    for text1, text2 in match:
        BVLSaddDir('','','','http://sebn.sc/images/logo.png', Folder=False)
        BVLSaddDir(text1 + ' ' + text2,'','','http://sebn.sc/images/logo.png', Folder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def BVLSMaandag(url):
    listhtml = getHtml(url, '')
    matchmaandag = re.compile("Programma Maandag(.*?)Programma Dinsdag", re.IGNORECASE | re.DOTALL).findall(listhtml)[0]
    datum = re.compile("(.*?)</h1>", re.IGNORECASE | re.DOTALL).findall(matchmaandag)[0]
    datum = 'Maandag' + datum
    totaalwedstrijd = re.compile('<div class="match-date">(.*?)/a></div></div></div>', re.IGNORECASE | re.DOTALL).findall(matchmaandag)[0]
    wedstrijd = re.compile('day">(.*?)</div>.*?">.*?">.*?class="(.*?)".*?name">(.*?)</div>.*?href="(.*?)"', re.IGNORECASE | re.DOTALL).findall(totaalwedstrijd)
    for tijd, img, name, url in wedstrijd:
            title = tijd + ' : '+ name
            if 'voetbal' in img:
                img = 'http://sebn.sc/schedule/images/voetbal.png'
            elif 'bel' in img:
                img = 'http://sebn.sc/schedule/images/belgium.png'
            elif 'eng' in img:
                img = 'http://sebn.sc/schedule/images/england.png'
            elif 'fra' in img:
                img = 'http://sebn.sc/schedule/images/france.png'
            elif 'dui' in img:
                img = 'http://sebn.sc/schedule/images/germany.png'
            elif 'ier' in img:
                img = 'http://sebn.sc/schedule/images/ireland.png'
            elif 'ita' in img:
                img = 'http://sebn.sc/schedule/images/italy.png'
            elif 'ned' in img:
                img = 'http://sebn.sc/schedule/images/netherlands.png'
            elif 'por' in img:
                img = 'http://sebn.sc/schedule/images/portugal.png'
            elif 'sco' in img:
                img = 'http://sebn.sc/schedule/images/scotland.png'
            elif 'spa' in img:
                img = 'http://sebn.sc/schedule/images/spain.png'
            elif 'tur' in img:
                img = 'http://sebn.sc/schedule/images/turkey.png'
            elif 'uk' in img:
                img = 'http://sebn.sc/schedule/images/united_kingdom.png'
            elif 'wal' in img:
                img = 'http://sebn.sc/schedule/images/wales.png'
            elif 'cl' in img:
                img = 'http://sebn.sc/schedule/images/cl.png'
            elif 'el' in img:
                img = 'http://sebn.sc/schedule/images/el.png'
            elif 'tv' in img:
                img = 'http://sebn.sc/schedule/images/tv.png'
            elif 'vi' in img:
                img = 'http://sebn.sc/schedule/images/vi.png'
            elif 'tvk' in img:
                img = 'http://sebn.sc/schedule/images/tvk.png'
            elif 'ron' in img:
                img = 'http://sebn.sc/schedule/images/rondo.png'
            elif 'wielrennen' in img:
                img = 'http://sebn.sc/schedule/images/wielrennen.png'
            elif 'basketbal' in img:
                img = 'http://sebn.sc/schedule/images/basketbal.png'
            elif 'pep' in img:
                img = 'http://sebn.sc/schedule/images/pep.png'
            elif 'dak' in img:
                img = 'http://sebn.sc/schedule/images/dakar.png'
            else:
                img = 'http://sebn.sc/images/logo.png'
            url = 'plugin://plugin.video.SportsDevil/?mode=1&item=catcher%3dstreams%26url=http://sebn.sc/' + url
            addDir(title,url,59,img , fanart,'','','','')
            
            streams = re.compile('href="(.*?)".*?">(.*?)<', re.IGNORECASE | re.DOTALL).findall(totaalwedstrijd)
            for name, url in streams:
                streams = '[COLOR cornflowerblue]- ' + name + '[/COLOR]'
                url = 'plugin://plugin.video.SportsDevil/?mode=1&item=catcher%3dstreams%26url=http://sebn.sc/' + url
                addDir(streams,'',59,'http://sebn.sc/images/logo.png' , fanart,'','','','')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
    
def BVLSDinsdag(url):
    listhtml = getHtml(url, '')
    matchdinsdag = re.compile("Programma Dinsdag(.*?)Programma Woensdag", re.IGNORECASE | re.DOTALL).findall(listhtml)[0]
    datum = re.compile("(.*?)</h1>", re.IGNORECASE | re.DOTALL).findall(matchdinsdag)[0]
    datum = 'Dinsdag' + datum
    totaalwedstrijd = re.compile('<div class="match-date">(.*?)/a></div></div></div>', re.IGNORECASE | re.DOTALL).findall(matchdinsdag)[0]
    wedstrijd = re.compile('day">(.*?)</div>.*?">.*?">.*?class="(.*?)".*?name">(.*?)</div>.*?href="(.*?)"', re.IGNORECASE | re.DOTALL).findall(totaalwedstrijd)
    for tijd, img, name, url in wedstrijd:
            title = tijd + ' : '+ name
            if 'voetbal' in img:
                img = 'http://sebn.sc/schedule/images/voetbal.png'
            elif 'bel' in img:
                img = 'http://sebn.sc/schedule/images/belgium.png'
            elif 'eng' in img:
                img = 'http://sebn.sc/schedule/images/england.png'
            elif 'fra' in img:
                img = 'http://sebn.sc/schedule/images/france.png'
            elif 'dui' in img:
                img = 'http://sebn.sc/schedule/images/germany.png'
            elif 'ier' in img:
                img = 'http://sebn.sc/schedule/images/ireland.png'
            elif 'ita' in img:
                img = 'http://sebn.sc/schedule/images/italy.png'
            elif 'ned' in img:
                img = 'http://sebn.sc/schedule/images/netherlands.png'
            elif 'por' in img:
                img = 'http://sebn.sc/schedule/images/portugal.png'
            elif 'sco' in img:
                img = 'http://sebn.sc/schedule/images/scotland.png'
            elif 'spa' in img:
                img = 'http://sebn.sc/schedule/images/spain.png'
            elif 'tur' in img:
                img = 'http://sebn.sc/schedule/images/turkey.png'
            elif 'uk' in img:
                img = 'http://sebn.sc/schedule/images/united_kingdom.png'
            elif 'wal' in img:
                img = 'http://sebn.sc/schedule/images/wales.png'
            elif 'cl' in img:
                img = 'http://sebn.sc/schedule/images/cl.png'
            elif 'el' in img:
                img = 'http://sebn.sc/schedule/images/el.png'
            elif 'tv' in img:
                img = 'http://sebn.sc/schedule/images/tv.png'
            elif 'vi' in img:
                img = 'http://sebn.sc/schedule/images/vi.png'
            elif 'tvk' in img:
                img = 'http://sebn.sc/schedule/images/tvk.png'
            elif 'ron' in img:
                img = 'http://sebn.sc/schedule/images/rondo.png'
            elif 'wielrennen' in img:
                img = 'http://sebn.sc/schedule/images/wielrennen.png'
            elif 'basketbal' in img:
                img = 'http://sebn.sc/schedule/images/basketbal.png'
            elif 'pep' in img:
                img = 'http://sebn.sc/schedule/images/pep.png'
            elif 'dak' in img:
                img = 'http://sebn.sc/schedule/images/dakar.png'
            else:
                img = 'http://sebn.sc/images/logo.png'
            url = 'plugin://plugin.video.SportsDevil/?mode=1&item=catcher%3dstreams%26url=http://sebn.sc/' + url
            addDir(title,url,59,img , fanart,'','','','')
            
            streams = re.compile('href="(.*?)".*?">(.*?)<', re.IGNORECASE | re.DOTALL).findall(totaalwedstrijd)
            for name, url in streams:
                streams = '[COLOR cornflowerblue]- ' + name + '[/COLOR]'
                url = 'plugin://plugin.video.SportsDevil/?mode=1&item=catcher%3dstreams%26url=http://sebn.sc/' + url
                addDir(streams,'',59,'http://sebn.sc/images/logo.png' , fanart,'','','','')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
    
def BVLSWoensdag(url):
    listhtml = getHtml(url, '')
    matchwoensdag = re.compile("Programma Woensdag(.*?)Programma Donderdag", re.IGNORECASE | re.DOTALL).findall(listhtml)[0]
    datum = re.compile("(.*?)</h1>", re.IGNORECASE | re.DOTALL).findall(matchdinsdag)[0]
    datum = 'Woensdag' + datum
    totaalwedstrijd = re.compile('<div class="match-date">(.*?)/a></div></div></div>', re.IGNORECASE | re.DOTALL).findall(matchwoensdag)[0]
    wedstrijd = re.compile('day">(.*?)</div>.*?">.*?">.*?class="(.*?)".*?name">(.*?)</div>.*?href="(.*?)"', re.IGNORECASE | re.DOTALL).findall(totaalwedstrijd)
    for tijd, img, name, url in wedstrijd:
            title = tijd + ' : '+ name
            if 'voetbal' in img:
                img = 'http://sebn.sc/schedule/images/voetbal.png'
            elif 'bel' in img:
                img = 'http://sebn.sc/schedule/images/belgium.png'
            elif 'eng' in img:
                img = 'http://sebn.sc/schedule/images/england.png'
            elif 'fra' in img:
                img = 'http://sebn.sc/schedule/images/france.png'
            elif 'dui' in img:
                img = 'http://sebn.sc/schedule/images/germany.png'
            elif 'ier' in img:
                img = 'http://sebn.sc/schedule/images/ireland.png'
            elif 'ita' in img:
                img = 'http://sebn.sc/schedule/images/italy.png'
            elif 'ned' in img:
                img = 'http://sebn.sc/schedule/images/netherlands.png'
            elif 'por' in img:
                img = 'http://sebn.sc/schedule/images/portugal.png'
            elif 'sco' in img:
                img = 'http://sebn.sc/schedule/images/scotland.png'
            elif 'spa' in img:
                img = 'http://sebn.sc/schedule/images/spain.png'
            elif 'tur' in img:
                img = 'http://sebn.sc/schedule/images/turkey.png'
            elif 'uk' in img:
                img = 'http://sebn.sc/schedule/images/united_kingdom.png'
            elif 'wal' in img:
                img = 'http://sebn.sc/schedule/images/wales.png'
            elif 'cl' in img:
                img = 'http://sebn.sc/schedule/images/cl.png'
            elif 'el' in img:
                img = 'http://sebn.sc/schedule/images/el.png'
            elif 'tv' in img:
                img = 'http://sebn.sc/schedule/images/tv.png'
            elif 'vi' in img:
                img = 'http://sebn.sc/schedule/images/vi.png'
            elif 'tvk' in img:
                img = 'http://sebn.sc/schedule/images/tvk.png'
            elif 'ron' in img:
                img = 'http://sebn.sc/schedule/images/rondo.png'
            elif 'wielrennen' in img:
                img = 'http://sebn.sc/schedule/images/wielrennen.png'
            elif 'basketbal' in img:
                img = 'http://sebn.sc/schedule/images/basketbal.png'
            elif 'pep' in img:
                img = 'http://sebn.sc/schedule/images/pep.png'
            elif 'dak' in img:
                img = 'http://sebn.sc/schedule/images/dakar.png'
            else:
                img = 'http://sebn.sc/images/logo.png'
            url = 'plugin://plugin.video.SportsDevil/?mode=1&item=catcher%3dstreams%26url=http://sebn.sc/' + url
            addDir(title,url,59,img , fanart,'','','','')
            
            streams = re.compile('href="(.*?)".*?">(.*?)<', re.IGNORECASE | re.DOTALL).findall(totaalwedstrijd)
            for name, url in streams:
                streams = '[COLOR cornflowerblue]- ' + name + '[/COLOR]'
                url = 'plugin://plugin.video.SportsDevil/?mode=1&item=catcher%3dstreams%26url=http://sebn.sc/' + url
                addDir(streams,'',59,'http://sebn.sc/images/logo.png' , fanart,'','','','')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
    
def BVLSDonderdag(url):
    listhtml = getHtml(url, '')
    matchdonderdag = re.compile("Programma Donderdag(.*?)Programma Vrijdag", re.IGNORECASE | re.DOTALL).findall(listhtml)[0]
    datum = re.compile("(.*?)</h1>", re.IGNORECASE | re.DOTALL).findall(matchdonderdag)[0]
    datum = 'Donderdag' + datum
    totaalwedstrijd = re.compile('<div class="match-date">(.*?)/a></div></div></div>', re.IGNORECASE | re.DOTALL).findall(matchdonderdag)[0]
    wedstrijd = re.compile('day">(.*?)</div>.*?">.*?">.*?class="(.*?)".*?name">(.*?)</div>.*?href="(.*?)"', re.IGNORECASE | re.DOTALL).findall(totaalwedstrijd)
    for tijd, img, name, url in wedstrijd:
            title = tijd + ' : '+ name
            if 'voetbal' in img:
                img = 'http://sebn.sc/schedule/images/voetbal.png'
            elif 'bel' in img:
                img = 'http://sebn.sc/schedule/images/belgium.png'
            elif 'eng' in img:
                img = 'http://sebn.sc/schedule/images/england.png'
            elif 'fra' in img:
                img = 'http://sebn.sc/schedule/images/france.png'
            elif 'dui' in img:
                img = 'http://sebn.sc/schedule/images/germany.png'
            elif 'ier' in img:
                img = 'http://sebn.sc/schedule/images/ireland.png'
            elif 'ita' in img:
                img = 'http://sebn.sc/schedule/images/italy.png'
            elif 'ned' in img:
                img = 'http://sebn.sc/schedule/images/netherlands.png'
            elif 'por' in img:
                img = 'http://sebn.sc/schedule/images/portugal.png'
            elif 'sco' in img:
                img = 'http://sebn.sc/schedule/images/scotland.png'
            elif 'spa' in img:
                img = 'http://sebn.sc/schedule/images/spain.png'
            elif 'tur' in img:
                img = 'http://sebn.sc/schedule/images/turkey.png'
            elif 'uk' in img:
                img = 'http://sebn.sc/schedule/images/united_kingdom.png'
            elif 'wal' in img:
                img = 'http://sebn.sc/schedule/images/wales.png'
            elif 'cl' in img:
                img = 'http://sebn.sc/schedule/images/cl.png'
            elif 'el' in img:
                img = 'http://sebn.sc/schedule/images/el.png'
            elif 'tv' in img:
                img = 'http://sebn.sc/schedule/images/tv.png'
            elif 'vi' in img:
                img = 'http://sebn.sc/schedule/images/vi.png'
            elif 'tvk' in img:
                img = 'http://sebn.sc/schedule/images/tvk.png'
            elif 'ron' in img:
                img = 'http://sebn.sc/schedule/images/rondo.png'
            elif 'wielrennen' in img:
                img = 'http://sebn.sc/schedule/images/wielrennen.png'
            elif 'basketbal' in img:
                img = 'http://sebn.sc/schedule/images/basketbal.png'
            elif 'pep' in img:
                img = 'http://sebn.sc/schedule/images/pep.png'
            elif 'dak' in img:
                img = 'http://sebn.sc/schedule/images/dakar.png'
            else:
                img = 'http://sebn.sc/images/logo.png'
            url = 'plugin://plugin.video.SportsDevil/?mode=1&item=catcher%3dstreams%26url=http://sebn.sc/' + url
            addDir(title,url,59,img , fanart,'','','','')
            
            streams = re.compile('href="(.*?)".*?">(.*?)<', re.IGNORECASE | re.DOTALL).findall(totaalwedstrijd)
            for name, url in streams:
                streams = '[COLOR cornflowerblue]- ' + name + '[/COLOR]'
                url = 'plugin://plugin.video.SportsDevil/?mode=1&item=catcher%3dstreams%26url=http://sebn.sc/' + url
                addDir(streams,'',59,'http://sebn.sc/images/logo.png' , fanart,'','','','')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
    
def BVLSVrijdag(url):
    listhtml = getHtml(url, '')
    matchvrijdag = re.compile("Programma Vrijdag(.*?)Programma Zaterdag", re.IGNORECASE | re.DOTALL).findall(listhtml)[0]
    datum = re.compile("(.*?)</h1>", re.IGNORECASE | re.DOTALL).findall(matchvrijdag)[0]
    datum = 'Vrijdag' + datum
    totaalwedstrijd = re.compile('<div class="match-date">(.*?)/a></div></div></div>', re.IGNORECASE | re.DOTALL).findall(matchvrijdag)[0]
    wedstrijd = re.compile('day">(.*?)</div>.*?">.*?">.*?class="(.*?)".*?name">(.*?)</div>.*?href="(.*?)"', re.IGNORECASE | re.DOTALL).findall(totaalwedstrijd)
    for tijd, img, name, url in wedstrijd:
            title = tijd + ' : '+ name
            if 'voetbal' in img:
                img = 'http://sebn.sc/schedule/images/voetbal.png'
            elif 'bel' in img:
                img = 'http://sebn.sc/schedule/images/belgium.png'
            elif 'eng' in img:
                img = 'http://sebn.sc/schedule/images/england.png'
            elif 'fra' in img:
                img = 'http://sebn.sc/schedule/images/france.png'
            elif 'dui' in img:
                img = 'http://sebn.sc/schedule/images/germany.png'
            elif 'ier' in img:
                img = 'http://sebn.sc/schedule/images/ireland.png'
            elif 'ita' in img:
                img = 'http://sebn.sc/schedule/images/italy.png'
            elif 'ned' in img:
                img = 'http://sebn.sc/schedule/images/netherlands.png'
            elif 'por' in img:
                img = 'http://sebn.sc/schedule/images/portugal.png'
            elif 'sco' in img:
                img = 'http://sebn.sc/schedule/images/scotland.png'
            elif 'spa' in img:
                img = 'http://sebn.sc/schedule/images/spain.png'
            elif 'tur' in img:
                img = 'http://sebn.sc/schedule/images/turkey.png'
            elif 'uk' in img:
                img = 'http://sebn.sc/schedule/images/united_kingdom.png'
            elif 'wal' in img:
                img = 'http://sebn.sc/schedule/images/wales.png'
            elif 'cl' in img:
                img = 'http://sebn.sc/schedule/images/cl.png'
            elif 'el' in img:
                img = 'http://sebn.sc/schedule/images/el.png'
            elif 'tv' in img:
                img = 'http://sebn.sc/schedule/images/tv.png'
            elif 'vi' in img:
                img = 'http://sebn.sc/schedule/images/vi.png'
            elif 'tvk' in img:
                img = 'http://sebn.sc/schedule/images/tvk.png'
            elif 'ron' in img:
                img = 'http://sebn.sc/schedule/images/rondo.png'
            elif 'wielrennen' in img:
                img = 'http://sebn.sc/schedule/images/wielrennen.png'
            elif 'basketbal' in img:
                img = 'http://sebn.sc/schedule/images/basketbal.png'
            elif 'pep' in img:
                img = 'http://sebn.sc/schedule/images/pep.png'
            elif 'dak' in img:
                img = 'http://sebn.sc/schedule/images/dakar.png'
            else:
                img = 'http://sebn.sc/images/logo.png'
            url = 'plugin://plugin.video.SportsDevil/?mode=1&item=catcher%3dstreams%26url=http://sebn.sc/' + url
            addDir(title,url,59,img , fanart,'','','','')
            
            streams = re.compile('href="(.*?)".*?">(.*?)<', re.IGNORECASE | re.DOTALL).findall(totaalwedstrijd)
            for name, url in streams:
                streams = '[COLOR cornflowerblue]- ' + name + '[/COLOR]'
                url = 'plugin://plugin.video.SportsDevil/?mode=1&item=catcher%3dstreams%26url=http://sebn.sc/' + url
                addDir(streams,'',59,'http://sebn.sc/images/logo.png' , fanart,'','','','')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
    
def BVLSZaterdag(url):
    listhtml = getHtml(url, '')
    matchzaterdag = re.compile("Programma Zaterdag(.*?)Programma Zondag", re.IGNORECASE | re.DOTALL).findall(listhtml)[0]
    datum = re.compile("(.*?)</h1>", re.IGNORECASE | re.DOTALL).findall(matchzaterdag)[0]
    datum = 'Zaterdag' + datum
    totaalwedstrijd = re.compile('<div class="match-date">(.*?)/a></div></div></div>', re.IGNORECASE | re.DOTALL).findall(matchzaterdag)[0]
    wedstrijd = re.compile('day">(.*?)</div>.*?">.*?">.*?class="(.*?)".*?name">(.*?)</div>.*?href="(.*?)"', re.IGNORECASE | re.DOTALL).findall(totaalwedstrijd)
    for tijd, img, name, url in wedstrijd:
            title = tijd + ' : '+ name
            if 'voetbal' in img:
                img = 'http://sebn.sc/schedule/images/voetbal.png'
            elif 'bel' in img:
                img = 'http://sebn.sc/schedule/images/belgium.png'
            elif 'eng' in img:
                img = 'http://sebn.sc/schedule/images/england.png'
            elif 'fra' in img:
                img = 'http://sebn.sc/schedule/images/france.png'
            elif 'dui' in img:
                img = 'http://sebn.sc/schedule/images/germany.png'
            elif 'ier' in img:
                img = 'http://sebn.sc/schedule/images/ireland.png'
            elif 'ita' in img:
                img = 'http://sebn.sc/schedule/images/italy.png'
            elif 'ned' in img:
                img = 'http://sebn.sc/schedule/images/netherlands.png'
            elif 'por' in img:
                img = 'http://sebn.sc/schedule/images/portugal.png'
            elif 'sco' in img:
                img = 'http://sebn.sc/schedule/images/scotland.png'
            elif 'spa' in img:
                img = 'http://sebn.sc/schedule/images/spain.png'
            elif 'tur' in img:
                img = 'http://sebn.sc/schedule/images/turkey.png'
            elif 'uk' in img:
                img = 'http://sebn.sc/schedule/images/united_kingdom.png'
            elif 'wal' in img:
                img = 'http://sebn.sc/schedule/images/wales.png'
            elif 'cl' in img:
                img = 'http://sebn.sc/schedule/images/cl.png'
            elif 'el' in img:
                img = 'http://sebn.sc/schedule/images/el.png'
            elif 'tv' in img:
                img = 'http://sebn.sc/schedule/images/tv.png'
            elif 'vi' in img:
                img = 'http://sebn.sc/schedule/images/vi.png'
            elif 'tvk' in img:
                img = 'http://sebn.sc/schedule/images/tvk.png'
            elif 'ron' in img:
                img = 'http://sebn.sc/schedule/images/rondo.png'
            elif 'wielrennen' in img:
                img = 'http://sebn.sc/schedule/images/wielrennen.png'
            elif 'basketbal' in img:
                img = 'http://sebn.sc/schedule/images/basketbal.png'
            elif 'pep' in img:
                img = 'http://sebn.sc/schedule/images/pep.png'
            elif 'dak' in img:
                img = 'http://sebn.sc/schedule/images/dakar.png'
            else:
                img = 'http://sebn.sc/images/logo.png'
            url = 'plugin://plugin.video.SportsDevil/?mode=1&item=catcher%3dstreams%26url=http://sebn.sc/' + url
            addDir(title,url,59,img , fanart,'','','','')
            
            streams = re.compile('href="(.*?)".*?">(.*?)<', re.IGNORECASE | re.DOTALL).findall(totaalwedstrijd)
            for name, url in streams:
                streams = '[COLOR cornflowerblue]- ' + name + '[/COLOR]'
                url = 'plugin://plugin.video.SportsDevil/?mode=1&item=catcher%3dstreams%26url=http://sebn.sc/' + url
                addDir(streams,'',59,'http://sebn.sc/images/logo.png' , fanart,'','','','')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
    
def BVLSZondag(url):
    listhtml = getHtml(url, '')
    matchzondag = re.compile('Programma Zondag(.*?)<div class="sidebarbox-title">', re.IGNORECASE | re.DOTALL).findall(listhtml)[0]
    datum = re.compile("(.*?)</h1>", re.IGNORECASE | re.DOTALL).findall(matchzondag)[0]
    datum = 'Zondag' + datum
    totaalwedstrijd = re.compile('<div class="match-date">(.*?)/a></div></div></div>', re.IGNORECASE | re.DOTALL).findall(matchzondag)[0]
    wedstrijd = re.compile('day">(.*?)</div>.*?">.*?">.*?class="(.*?)".*?name">(.*?)</div>.*?href="(.*?)"', re.IGNORECASE | re.DOTALL).findall(totaalwedstrijd)
    for tijd, img, name, url in wedstrijd:
            title = tijd + ' : '+ name
            if 'voetbal' in img:
                img = 'http://sebn.sc/schedule/images/voetbal.png'
            elif 'bel' in img:
                img = 'http://sebn.sc/schedule/images/belgium.png'
            elif 'eng' in img:
                img = 'http://sebn.sc/schedule/images/england.png'
            elif 'fra' in img:
                img = 'http://sebn.sc/schedule/images/france.png'
            elif 'dui' in img:
                img = 'http://sebn.sc/schedule/images/germany.png'
            elif 'ier' in img:
                img = 'http://sebn.sc/schedule/images/ireland.png'
            elif 'ita' in img:
                img = 'http://sebn.sc/schedule/images/italy.png'
            elif 'ned' in img:
                img = 'http://sebn.sc/schedule/images/netherlands.png'
            elif 'por' in img:
                img = 'http://sebn.sc/schedule/images/portugal.png'
            elif 'sco' in img:
                img = 'http://sebn.sc/schedule/images/scotland.png'
            elif 'spa' in img:
                img = 'http://sebn.sc/schedule/images/spain.png'
            elif 'tur' in img:
                img = 'http://sebn.sc/schedule/images/turkey.png'
            elif 'uk' in img:
                img = 'http://sebn.sc/schedule/images/united_kingdom.png'
            elif 'wal' in img:
                img = 'http://sebn.sc/schedule/images/wales.png'
            elif 'cl' in img:
                img = 'http://sebn.sc/schedule/images/cl.png'
            elif 'el' in img:
                img = 'http://sebn.sc/schedule/images/el.png'
            elif 'tv' in img:
                img = 'http://sebn.sc/schedule/images/tv.png'
            elif 'vi' in img:
                img = 'http://sebn.sc/schedule/images/vi.png'
            elif 'tvk' in img:
                img = 'http://sebn.sc/schedule/images/tvk.png'
            elif 'ron' in img:
                img = 'http://sebn.sc/schedule/images/rondo.png'
            elif 'wielrennen' in img:
                img = 'http://sebn.sc/schedule/images/wielrennen.png'
            elif 'basketbal' in img:
                img = 'http://sebn.sc/schedule/images/basketbal.png'
            elif 'pep' in img:
                img = 'http://sebn.sc/schedule/images/pep.png'
            elif 'dak' in img:
                img = 'http://sebn.sc/schedule/images/dakar.png'
            else:
                img = 'http://sebn.sc/images/logo.png'
            url = 'plugin://plugin.video.SportsDevil/?mode=1&item=catcher%3dstreams%26url=http://sebn.sc/' + url
            addDir(title,url,59,img , fanart,'','','','')
            
            streams = re.compile('href="(.*?)".*?">(.*?)<', re.IGNORECASE | re.DOTALL).findall(totaalwedstrijd)
            for name, url in streams:
                streams = '[COLOR cornflowerblue]- ' + name + '[/COLOR]'
                url = 'plugin://plugin.video.SportsDevil/?mode=1&item=catcher%3dstreams%26url=http://sebn.sc/' + url
                addDir(streams,'',59,'http://sebn.sc/images/logo.png' , fanart,'','','','')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))